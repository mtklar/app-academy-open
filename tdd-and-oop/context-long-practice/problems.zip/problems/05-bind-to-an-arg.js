function bindToAnArg(func, arg) {
  return func.bind(func, arg);
}

/**************DO NOT MODIFY ANYTHING UNDER THIS  LINE*****************/
module.exports = bindToAnArg;
